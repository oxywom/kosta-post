package com.kosta.api.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import com.kosta.api.dto.UserInfo;

@Service
public class KakaoLoginService {

	public UserInfo kakaoLogin(String code) throws Exception {
		String token = getAccessToken(code);
		System.out.println(token);
		UserInfo userInfo = getUserInfo(token);
		return userInfo;
	}
	
	public String getAccessToken(String code) throws Exception {
		StringBuilder urlBuilder = new StringBuilder("https://kauth.kakao.com/oauth/token");
		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-type", "application/x-www-form-urlencoded;charset=utf-8");
		conn.setDoOutput(true); //출력스트림 활성화(파라미터 body 영역에 넣기위해)
		
		//파라미터 생성
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
		StringBuilder param = new StringBuilder();
		param.append("grant_type=authorization_code");
		param.append("&client_id=d242acd72494edb5aae8ee8e881ae067");
		param.append("&redirect_uri=http://localhost:8090/api/kakaologin");
		param.append("&code="+code);
		
		//생성한 파라미터를 출력스트림에 쓰기(body에 넣기)
		bw.write(param.toString());
		bw.flush();
		
		BufferedReader br;
		int resultCode = conn.getResponseCode(); 
		
		if(resultCode>=200 && resultCode<=300) { //정상
			br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else { //에러
			br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		
		StringBuilder resBuilder = new StringBuilder();
		String line;
		while((line=br.readLine())!=null) {
			resBuilder.append(line);
		}
		br.close();
		conn.disconnect();
		System.out.println(resBuilder.toString());
		
		JSONParser parser = new JSONParser();
		JSONObject tokenObj =  (JSONObject)parser.parse(resBuilder.toString());
		String token = (String)tokenObj.get("access_token");
		return token;
	}
	
	public UserInfo getUserInfo(String token) throws Exception {
		StringBuilder urlBuilder = new StringBuilder("https://kapi.kakao.com/v2/user/me");
		URL url = new URL(urlBuilder.toString());
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Authorization", "Bearer "+token);

		BufferedReader br;
		int resultCode = conn.getResponseCode(); 
		
		if(resultCode>=200 && resultCode<=300) { //정상
			br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else { //에러
			br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}
		
		StringBuilder resBuilder = new StringBuilder();
		String line;
		while((line=br.readLine())!=null) {
			resBuilder.append(line);
		}
		br.close();
		conn.disconnect();
		System.out.println(resBuilder.toString());

		JSONParser parser = new JSONParser();
		JSONObject user =  (JSONObject)parser.parse(resBuilder.toString());
		Long id = (Long)user.get("id");
		JSONObject properties = (JSONObject)user.get("properties");
		String nickname = (String)properties.get("nickname");
		String profileImage = (String)properties.get("profile_image");
		String thumbnailImage = (String)properties.get("thumbnail_image");
		
		JSONObject kakaoAccount = (JSONObject)user.get("kakao_account");
		String email = (String)kakaoAccount.get("email");
		String gender = (String)kakaoAccount.get("gender");

		UserInfo userInfo = new UserInfo(id, nickname, profileImage, thumbnailImage, email, gender);
		
		return userInfo;
	}
}