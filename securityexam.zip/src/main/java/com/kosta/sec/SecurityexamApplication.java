package com.kosta.sec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityexamApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityexamApplication.class, args);
	}

}
