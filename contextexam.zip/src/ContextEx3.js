import ContextEx4 from "./ContextEx4";
const ContextEx3 = () => {
    return(
        <>
            <h1>ContextEx3</h1>
            <ContextEx4/>
        </>
    )
}
export default ContextEx3;