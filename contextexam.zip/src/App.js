import logo from './logo.svg';
import './App.css';
import ContextEx1 from './ContextEx1';

function App() {
  return (
    <div className="App">
      <ContextEx1/>
    </div>
  );
}

export default App;
