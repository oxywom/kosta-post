import ContextEx3 from './ContextEx3';
const ContextEx2 = () => {
    return(
        <>
            <h1>ContextEx2</h1>
            <ContextEx3/>
        </>
    )
}

export default ContextEx2;