import ContextEx5 from "./ContextEx5";
const ContextEx4 = () => {
    return(
        <>
            <h1>ContextEx4</h1>
            <ContextEx5/>
        </>
    )
}

export default ContextEx4;