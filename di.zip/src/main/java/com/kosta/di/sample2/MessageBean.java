package com.kosta.di.sample2;

public interface MessageBean {
	void sayHello();
}
