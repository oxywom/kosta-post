package com.kosta.di.sample1;

public interface MessageBean {
	void sayHello(String name);
}
