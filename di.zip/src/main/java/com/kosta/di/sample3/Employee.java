package com.kosta.di.sample3;

public interface Employee {
	void info();
}
