import {UncontrolledCollapse,Button,CardBody,Card} from "reactstrap";
function CollapseStrap() {
    return(
        <>
            <Button style={{marginBottom:"10px"}} color="warning" id="toggle">펼치기/접기</Button>
            <UncontrolledCollapse toggler="#toggle">
                <Card style={{width:"300px"}}>
                    <CardBody>
                    고용노동부는 11월 또다시 노동시간
                    관련 정책을 발표한다고 한다.
                    어떤 정책을 발표할지 모르겠지만
                    일과 삶의 균형을 파괴하는 정책이
                    아니길 바랄 뿐이다.
                    한국은 국제노동기구(ILO) 노동시간
                    협약 중 1935년에 채택된 47호 
                    협약(주 40시간)만 비준한 상태다.
                    ILO나 유럽연합(EU) 등에서도 
                    노동시간 규제는 주요 핵심 의제다.
                    </CardBody>
                </Card>
            </UncontrolledCollapse><br/>
            <Button style={{marginBottom:"10px"}} color="warning">테스트 버튼</Button>
        </>
    )
}

export default CollapseStrap;