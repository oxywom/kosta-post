import {UncontrolledCarousel} from 'reactstrap';
const items = [
    {
        src:'namo3.jpg',
        altText:'나무',
        caption:'namo caption',
        header:'namo header'
    },
    {
        src:'flower2.jpg',
        altText:'꽃2',
        caption:'flower2 caption',
        header:'flower2 header'
    },
    {
        src:'flower3.jpg',
        altText:'꽃3',
        caption:'flower3 caption',
        header:'flower3 header'
    }

];

function CarouselStrap() {
    return(
        <UncontrolledCarousel items={items}/>
    )
}

export default CarouselStrap;