import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import AlertStrap from './AlertStrap';
import ButtonStrap from './ButtonStrap';
import BreadCrumbStrap from './BreadCrumbStrap';
import DropdownStrap from './DropdownStrap';
import ButtonGroupStrap from './ButtonGroupStrap';
import CardStrap from './CardStrap';
import CarouselStrap from './CarouselStrap';
import CollapseStrap from './CollapseStrap';
import CollapseStrap2 from './CollapseStrap2';
import FadeStrap from './FadeStrap';
import FormStrap from './FormStrap';
function App() {
  return (
    <div>
      {/* <AlertStrap/> */}
      {/* <ButtonStrap/> */}
      {/* <BreadCrumbStrap/> */}
      {/* <DropdownStrap/> */}
      {/* <ButtonGroupStrap/> */}
      {/* <CardStrap/> */}
      {/* <CarouselStrap/> */}
      {/* <CollapseStrap/> */}
      {/* <CollapseStrap2/> */}
      {/* <FadeStrap/> */}
      <FormStrap/>
    </div>
  );
}

export default App;
