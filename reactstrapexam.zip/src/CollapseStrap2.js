import { useState } from 'react';
import {Collapse, Button,Card,CardBody} from 'reactstrap';
function CollapseStrap2() {
    const [open, setOpen] = useState(false);
    const [status, setStatus] = useState("Closed");
    const [idx, setIdx] = useState(0);
    const contents = [
        "고용노동부는 11월 또다시 노동시간 관련 정책을 발표한다고 한다. 어떤 정책을 발표할지 모르겠지만 일과 삶의 균형을 파괴하는 정책이 아니길 바랄 뿐이다. 한국은 국제노동기구(ILO) 노동시간 협약 중 1935년에 채택된 47호 협약(주 40시간)만 비준한 상태다. ILO나 유럽연합(EU) 등에서도 노동시간 규제는 주요 핵심 의제다.",
        "ILO는 좋은 일자리의 한 형태로 '괜찮은 노동시간 편성'을 강조했다. 균형 있는 노동시간 편성으로 노동자들이 일·생활 균형을 찾고 건강을 유지해 결근과 이직이 감소하며, 노동자들의 태도가 좋아지고 사기가 진작되며, 기업의 지속가능성이 향상되어 기업에게도 이익이 된다는 점을 ILO는 강조한다. 때문에 장시간 노동의 규제와 더불어 균형 있는 노동시간의 편성·배열은 매우 중요하다.",
        "조사 결과 주당 평균 52시간 이상 장시간 노동 비율은 8.1%였다. 장시간 노동은 교대 근무자와 저임금 노동자 집단에서 더 많았다. 지난 한 해 동안 법정 연차휴가 사용은 평균 8.6일에 불과 했다. 비정규직(5.9일)과 최저임금 이하(5.5일), 교대 근무자(6.4일)는 가장 적은 연차휴가를 사용한 집단이었다."
    ]
    const entering = () => {
        setStatus("Opening");
        if(idx===contents.length-1) setIdx(0);
        else setIdx(idx+1);
    }
    const entered = () => {
        setStatus("Opened");
    }
    const exiting = () => {
        setStatus("Closing");
    }
    const exited = () => {
        setStatus("Closed");
    }
    return(
        <div>
            <Button onClick={()=>setOpen(!open)} style={{marginBottom:"10px"}}>Toggle</Button>
            <h5>Current state: {status}</h5>
            <Collapse isOpen={open}
                onEntering={entering}
                onEntered={entered}
                onExiting={exiting}
                onExited={exited}>
                <Card>
                    <CardBody>
                        {contents[idx]}
                    </CardBody>
                </Card>
            </Collapse>
        </div>
    )
}

export default CollapseStrap2;