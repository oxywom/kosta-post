import './App.css';
import FStateComp from './FStateComp';
import MyInfo from './MyInfo';

function App() {
  return (
    <div className="App">
      {/* <StateComp/> */}
      {/* <FStateComp/> */}
      <MyInfo/>
    </div>
  );
}

export default App;
