import './App.css';
import ReducerEx1 from './ReducerEx1';
function App() {
  return (
    <div className="App">
      <ReducerEx1/>
    </div>
  );
}

export default App;
