package com.kosta.sec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Securityjwtoauth2examApplication {

	public static void main(String[] args) {
		SpringApplication.run(Securityjwtoauth2examApplication.class, args);
	}

}
