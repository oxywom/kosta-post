package dao;

import java.util.ArrayList;
import java.util.List;

import dto.Team;

public class TeamDAO {
	public int insertTeam(Team team) {
		int cnt=0;
		
		return cnt;
	}
	
	public Team selectTeam(String teamName) {
		Team team = null;
		
		return team;
	}
	
	public List<Team> selectTeamList() {
		List<Team> teamList = new ArrayList<>();
		
		return teamList;
	}
}
