import {useState} from 'react';

const ChatMain = () => {
    const [channelId, setChannelId] = useState();
    const [writerId, setWriterId] = useState();
    const openChat = () => {
      window.open(`/chat/${channelId}/${writerId}`, "_blank");
    }

    return (
        <div>
            <input type="text" onInput={(e) => setChannelId(e.target.value)} />
            <input type="text" onInput={(e) => setWriterId(e.target.value)} />
            <button onClick={openChat}>채팅열기</button>
        </div>        
    )
}

export default ChatMain;