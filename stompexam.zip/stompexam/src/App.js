import './App.css';
import {BrowserRouter} from 'react-router-dom';
import {Routes, Route} from 'react-router-dom';
import ChatMain from './ChatMain';
import StompChatting from './StompChatting';

function App() {

  return (
      <BrowserRouter>
        <Routes>
          <Route exect path="/" element={<ChatMain />} />
          <Route exect path="/chat/:channelId/:writerId" element={<StompChatting />} />
        </Routes>
      </BrowserRouter>
);
}

export default App;
