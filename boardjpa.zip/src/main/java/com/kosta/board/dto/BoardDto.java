package com.kosta.board.dto;

import java.sql.Date;

import com.kosta.board.entity.Board;
import com.kosta.board.entity.Member;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoardDto {
	private Integer num;
	private String subject;
	private String content;
	private Date writedate;
	private String fileurl;
	private String writer;
	private Integer viewcount;
	private Integer likecount;
	private String writername;
	
	public Board toEntity () {
		return Board.builder()
				.num(num)
				.subject(subject)
				.content(content)
				.fileurl(fileurl)
				.member(Member.builder().id(writer).build())
				.viewcount(viewcount)
				.likecount(likecount)
				.writedate(writedate)
				.build();
	}
}
