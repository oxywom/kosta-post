package com.kosta.board.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicInsert;

import com.kosta.board.dto.BoardDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@DynamicInsert
public class Board {
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer num;
	
	@Column
	private String subject;
	@Column
	private String content;
	@Column
	private String fileurl;
	
	@Column
	@ColumnDefault("0")
	private Integer viewcount;
	
	@Column
	@ColumnDefault("0")
	private Integer likecount;
	
	@Column
	@CreationTimestamp
	private Date writedate;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="writer")
	private Member member;
	
	@Override
	public String toString() {
		return String.format("[%d,%s,%s,%s,%s]", num,subject,content,fileurl,member.getId());
	}
	
	public BoardDto toDto() {
		return BoardDto.builder()
				.num(num)
				.subject(subject)
				.content(content)
				.fileurl(fileurl)
				.writer(member.getId())
				.writername(member.getName())
				.viewcount(viewcount)
				.likecount(likecount)
				.writedate(writedate)
				.build();		
	}
}
