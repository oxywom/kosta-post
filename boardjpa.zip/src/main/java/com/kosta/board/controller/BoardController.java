package com.kosta.board.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kosta.board.dto.BoardDto;
import com.kosta.board.service.BoardService;
import com.kosta.board.util.PageInfo;

@RestController
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	@GetMapping({"/boardlist/{page}", "/boardlist"})
	public ResponseEntity<Map<String,Object>> boardList(@PathVariable(required = false) Integer page) {
		try {
			PageInfo pageInfo = new PageInfo(page);
			List<BoardDto> boardList = boardService.boardListByPage(pageInfo);
			Map<String,Object> res = new HashMap<>();
			res.put("boardList", boardList);
			res.put("pageInfo", pageInfo);
			return new ResponseEntity<Map<String,Object>>(res, HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Map<String,Object>>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/boardsearch/{page}/{type}/{keyword}")
	public ResponseEntity<Map<String,Object>> boardSearch(@PathVariable(required = false) Integer page,
			@PathVariable(required = false) String type, @PathVariable(required = false) String keyword) {
		try {
			PageInfo pageInfo = new PageInfo(page);
			List<BoardDto> boardList = boardService.searchListByPage(type, keyword, pageInfo);
			Map<String,Object> res = new HashMap<>();
			res.put("boardList", boardList);
			res.put("pageInfo", pageInfo);
			return new ResponseEntity<Map<String,Object>>(res, HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Map<String,Object>>(HttpStatus.BAD_REQUEST);
		}
	}
	
	//@GetMapping("/boarddelete/{num}")
	@DeleteMapping("/boarddelete/{num}")
	public ResponseEntity<Integer> boardDelete(@PathVariable Integer num) {
		try {
			boardService.boardDelete(num);
			return new ResponseEntity<Integer>(num, HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Integer>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/boarddetail/{num}")
	public ResponseEntity<Map<String,Object>> boardDetail(@PathVariable Integer num) {
		try {
			BoardDto board = boardService.boardDetail(num);
			Boolean heart = boardService.isHeartBoard(null, num);
			
			Map<String,Object> res = new HashMap<>();
			res.put("board", board);
			//res.put("heart", heart);
			res.put("heart", false);
			return new ResponseEntity<Map<String,Object>>(res, HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Map<String,Object>>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/img/{num}")
	public void imageView(@PathVariable Integer num, HttpServletResponse response) {
		try {
			boardService.readImage(num, response.getOutputStream());
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@PostMapping("/boardwrite")
	public ResponseEntity<Integer> boardWrite(@ModelAttribute BoardDto board, List<MultipartFile> file) {
		try {
			Integer num = boardService.boardWrite(board, file);
			return new ResponseEntity<Integer>(num, HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Integer>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/boardmodify")
	public ResponseEntity<Integer> boardModify(@ModelAttribute BoardDto board, @RequestParam(value="file",required=false) List<MultipartFile> file) {
		try {
			Integer num = boardService.boardModify(board, file);
			return new ResponseEntity<Integer>(num, HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Integer>(HttpStatus.BAD_REQUEST);
		}
	}	
}
