package com.kosta.board.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kosta.board.entity.FileVo;

public interface FileVoRepository extends JpaRepository<FileVo, Integer> {

}
