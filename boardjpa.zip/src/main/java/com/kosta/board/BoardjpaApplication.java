package com.kosta.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardjpaApplication.class, args);
	}

}
