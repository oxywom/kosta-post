package com.kosta.board.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import com.kosta.board.dto.BoardDto;
import com.kosta.board.entity.Board;
import com.kosta.board.entity.FileVo;
import com.kosta.board.repository.BoardRepository;
import com.kosta.board.repository.FileVoRepository;
import com.kosta.board.util.PageInfo;

@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardRepository boardRepository;

	@Autowired
	private FileVoRepository fileVoRepository;

	@Override
	public List<BoardDto> boardListByPage(PageInfo pageInfo) throws Exception {
		PageRequest pageRequest = PageRequest.of(pageInfo.getCurPage()-1,10, 
				Sort.by(Sort.Direction.DESC,"num"));
		Page<Board> pages =  boardRepository.findAll(pageRequest);
		pageInfo.setAllPage(pages.getTotalPages());
		int startPage = (pageInfo.getCurPage()-1)/10*10+1;
		int endPage = Math.min(startPage+10-1, pageInfo.getAllPage());
		pageInfo.setStartPage(startPage);
		pageInfo.setEndPage(endPage);
		List<BoardDto> boardDtoList = new ArrayList<>(); 
		for(Board board : pages.getContent()) {
			boardDtoList.add(board.toDto());
		}
		return boardDtoList;
	}

	@Override
	public BoardDto boardDetail(Integer num) throws Exception {
		Optional<Board> oboard = boardRepository.findById(num);
		if(oboard.isEmpty()) throw new Exception("글번호 오류");
		return oboard.get().toDto();
	}

	@Override
	public void readImage(Integer num, OutputStream out) throws Exception {
		String dir = "c:/hyj/upload/";
		FileInputStream fis = new FileInputStream(dir+num);
		FileCopyUtils.copy(fis, out);
		fis.close();
	}

	@Override
	public Integer boardWrite(BoardDto boardDto, List<MultipartFile> files) throws Exception {
		String dir = "c:/hyj/upload/";
		if(files!=null && files.size()!=0) {
			String fileNums = "";
			for(MultipartFile file : files) {
				//file table에 insert
				FileVo fileVo = FileVo.builder()
						.directory(dir)
						.name(file.getOriginalFilename())
						.size(file.getSize())
						.contenttype(file.getContentType())
						.data(file.getBytes()).build();
				fileVoRepository.save(fileVo);

				//upload 폴더에 upload
				File uploadFile = new File(dir+fileVo.getNum());
				file.transferTo(uploadFile);
				
				//file번호 목록 만들기
				if(!fileNums.equals("")) 
					fileNums += ",";
				fileNums += fileVo.getNum(); 
			}
			boardDto.setFileurl(fileNums);  //1,2,3
		}
		//board table에 insert
		Board board = boardDto.toEntity();
		boardRepository.save(board);
		return board.getNum();
	}

	@Override
	public Integer boardModify(BoardDto board, List<MultipartFile> fileInfo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void boardDelete(Integer num) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<BoardDto> searchListByPage(String type, String keyword, PageInfo pageInfo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean isHeartBoard(String id, Integer num) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void selHeartBoard(String id, Integer num) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delHeartBoard(String id, Integer num) throws Exception {
		// TODO Auto-generated method stub
		
	}
}