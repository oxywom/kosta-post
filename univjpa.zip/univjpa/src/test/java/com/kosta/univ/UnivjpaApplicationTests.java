package com.kosta.univ;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.kosta.univ.entity.Department;
import com.kosta.univ.entity.Professor;
import com.kosta.univ.entity.Student;
import com.kosta.univ.service.UnivService;

@SpringBootTest
class UnivjpaApplicationTests {
	@Autowired
	private UnivService univService;
	
	@Test
	void contextLoads() {
	}

	@Test
	void studentListByName() {
		try {
			List<Student> sList = univService.studentListByName("일지매");
			System.out.println(sList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void studentListInDept1ByDeptName() {
		try {
			List<Student> sList = univService.studentListInDept1ByDeptName("전자공학과");
			System.out.println(sList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void studentListInDept2ByDeptName() {
		try {
			List<Student> sList = univService.studentListInDept2ByDeptName("전자공학과");
			System.out.println(sList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void studentListByGrade() {
		try {
			List<Student> sList = univService.studentListByGrade(1);
			System.out.println(sList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void studentListByNoProfessor() {
		try {
			List<Student> sList = univService.studentListByNoProfessor();
			System.out.println(sList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void studentByStudno() {
		try {
			Student student = univService.studentByStudno(9411);
			System.out.println(student);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void studentByJumin() {
		try {
			Student student = univService.studentByJumin("7601232186327");
			System.out.println(student);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void studentListByProfNo() {
		try {
			List<Student> sList = univService.studentListByProfNo(4003);
			System.out.println(sList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void studentListByProfName() {
		try {
			List<Student> sList = univService.studentListByProfName("조인형");
			System.out.println(sList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void professorByProfNo() {
		try {
			Professor professor = univService.professorByProfNo(1001);
			System.out.println(professor);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void professorListByProfName() {
		try {
			List<Professor> professorList = univService.professorListByProfName("조인형");
			System.out.println(professorList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void professorListByDeptNo() {
		try {
			List<Professor> professorList = univService.professorListByDeptNo(101);
			System.out.println(professorList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void professorListByDeptName() {
		try {
			List<Professor> professorList = univService.professorListByDeptName("컴퓨터공학과");
			System.out.println(professorList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void professorListByPosition() {
		try {
			List<Professor> professorList = univService.professorListByPosition("정교수");
			System.out.println(professorList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void departmentByDeptNo() {
		try {
			Department department = univService.departmentByDeptNo(101);
			System.out.println(department);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void departmentByDeptName() {
		try {
			Department department = univService.departmentByDeptName("컴퓨터공학과");
			System.out.println(department);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void departmentListByPart() {
		try {
			List<Department> departmentList = univService.departmentListByPart(100);
			System.out.println(departmentList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	void departmentListByBuild() {
		try {
			List<Department> departmentList = univService.departmentListByBuild("멀티미디어관");
			System.out.println(departmentList);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}


