package com.kosta.univ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnivjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnivjpaApplication.class, args);
	}

}
