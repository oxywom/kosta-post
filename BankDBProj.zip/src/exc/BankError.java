package exc;

public enum BankError {
	NOID, EXISTID, LACK, MINUS, MENU
}
