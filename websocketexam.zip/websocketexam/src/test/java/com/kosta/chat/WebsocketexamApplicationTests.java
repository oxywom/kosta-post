package com.kosta.chat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
