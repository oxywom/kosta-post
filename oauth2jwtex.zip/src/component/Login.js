import {useState} from 'react';
import axios from 'axios';
import {useDispatch} from 'react-redux';

const Login = () => {
    const [user, setUser] = useState({username:'',password:''});
    const dispatch = useDispatch();

    const changeUser = (e) => {
        setUser({...user, [e.target.name]:e.target.value});
    }
    const login = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8090/login", user)
            .then(res=> {
                console.log(res.headers.authorization);
                dispatch({type:"token", payload:res.headers.authorization});
            })
            .catch(err=> {
                console.log(err);
            })
    }
    const oauth2login = (e,registration) => {
        e.preventDefault();
        axios.get(`http://localhost:8090/oauth2/authorization/${registration}`, user)
            .then(res=> {
                console.log(res.headers.authorization);
                dispatch({type:"token", payload:res.headers.authorization});
            })
            .catch(err=> {
                console.log(err);
            })
    }

    return(
        <>
        <h2>로그인</h2>
        <table border="1">
            <tbody>
            <tr>
            <td><label>username</label></td>
            <td><input name="username" value={user.username} onInput={changeUser}/></td>
            </tr>
            <tr>
            <td><label>passowrd</label></td>
            <td><input name="password" value={user.password} onInput={changeUser}/></td>
            </tr>
            <tr>
                <td colSpan="2"><button onClick={login}>로그인</button></td>
            </tr>
            <tr>
                <td colSpan="2"><button onClick={(e)=>oauth2login(e,"naver")}>네이버로그인</button></td>
            </tr>
            <tr>
                <td colSpan="2"><button onClick={(e)=>oauth2login(e,"kakao")}>카카오로그인</button></td>
            </tr>
            </tbody>
        </table>
        </>
    )
}

export default Login;