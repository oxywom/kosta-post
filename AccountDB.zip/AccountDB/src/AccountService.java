import java.sql.Connection;

public class AccountService {
	public void accountInfo(String id) {
		Connection conn = Dao.getConnection();
		Account acc = Dao.selectAccount(conn,id);
		if(acc==null) {
			System.out.println("없는 계좌입니다.");
		} else {
			System.out.println(acc);	
		}
		Dao.close(conn);
	}
	public void makeAccount(Account acc) {
		Connection conn = Dao.getConnection();
		Account racc = Dao.selectAccount(conn,acc.getId());
		if(racc!=null) {
			System.out.println("중복 계좌번호입니다.");
		} else {
			int cnt = Dao.insertAccount(conn, acc);
			if(cnt>0) {
				System.out.println(cnt+"개 계좌가 개설되었습니다.");
			}
		}
		Dao.close(conn);
	}
}
