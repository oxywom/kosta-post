import { useState } from "react";
import {Button,Modal,ModalHeader,ModalBody,ModalFooter} from 'reactstrap';
function ModalStrap3() {
    const [modal,setModal] = useState(false);
    const [nestedModal,setNestedModal] = useState(false);
    const toggle = () => { setModal(!modal) }
    const toggleNested = () => { setNestedModal(!nestedModal) }
    const toggleAll = () => { 
        setNestedModal(false);
        setModal(false);
    }
    return(
        <div style={{width:"800px"}}>
            <Button color="danger" onClick={toggle}>첫 모달</Button>
            <Modal isOpen={modal} toggle={toggle}>
                <ModalHeader toggle={toggle}>애플TV 월 9.99달러로 인상</ModalHeader>
                <ModalBody>
                현지 시간 25일 애플은 “오늘부터 미국 등 일부 시장에서 애플TV 플러스와 아케이드, 뉴스 플러스, 애플 원 등의 요금을 인상한다”고 밝혔습니다.
                <br/>
                <Button color="success" onClick={toggleNested}>두번째 모달</Button>
                <Modal isOpen={nestedModal} toggle={toggleNested}>
                    <ModalHeader toggle={toggleNested}>애플의 구독형 게임 서비스</ModalHeader>
                    <ModalBody>
                    아케이드는 애플의 구독형 게임 서비스며, 뉴스 플러스는 신문과 잡지 등을 제공하는 뉴스 서비스입니다. 애플 원은 이들을 종합한 패키지 서비스입니다.
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" onClick={toggleNested}>닫기</Button>
                        <Button color="secondary" onClick={toggleAll}>전체닫기</Button>
            </ModalFooter>
                </Modal>
                </ModalBody>
                <ModalFooter>
                    <Button color="primary" onClick={toggle}>처리</Button>
                    <Button color="secondary" onClick={toggle}>취소</Button>
                </ModalFooter>
            </Modal>
        </div>
    )
}
export default ModalStrap3;