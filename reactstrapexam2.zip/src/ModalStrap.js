import { useState } from 'react';
import {Button, Modal, ModalHeader,ModalBody,ModalFooter} from 'reactstrap';
function ModalStrap() {
    const [open, setOpen] = useState(false);
    return(
        <div>
            <Button color="danger" onClick={()=>setOpen(true)}>모달</Button>
            <Modal isOpen={open} toggle={()=>setOpen(!open)}>
                <ModalHeader toggle={()=>setOpen(!open)}>인성 키움! 북 페스티벌 개최</ModalHeader>
                <ModalBody>
                부산시교육청이 오는 27일과 28일 이틀간 송상현 광장에서 ‘인성 키움! 북 페스티벌’ 행사를 개최한다.
                올해 처음 진행되는 이번 행사는 학생과 학부모에게 독서의 즐거움을 일깨우고, 독서 활동으로 소중한 가치를 나누는 등 독서 문화 확산을 위해 개최된다.
                </ModalBody>
                <ModalFooter>
                    <Button color="primary" onClick={()=>setOpen(!open)}>확인</Button>{' '}
                    <Button color="secondary" onClick={()=>setOpen(!open)}>취소</Button>
                </ModalFooter>
            </Modal>
        </div>
    )
}

export default ModalStrap;