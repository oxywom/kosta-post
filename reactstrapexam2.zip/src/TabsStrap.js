import { useState } from "react";
import { TabContent,TabPane,Nav,NavItem,NavLink,Card,Button,CardTitle,CardText,Row,Col } from "reactstrap";
import classnames from 'classnames';
function TabsStrap() {
    const [activeTab, setActiveTab] = useState('1');
    return(
        <div style={{width:"800px"}}>
            <Nav tabs>
                <NavItem>
                    <NavLink 
                        className={activeTab==='1'? "active":""}
                        //className={classnames({active:activeTab==='1'})}
                        onClick={()=>setActiveTab('1')}>Tab1</NavLink>
                </NavItem>
                <NavItem>
                    <NavLink 
                        className={activeTab==='2'? "active":""}
                        //className={classnames({active:activeTab==='2'})}
                        onClick={()=>setActiveTab('2')}>Tab2</NavLink>
                </NavItem>
            </Nav>
            <TabContent activeTab={activeTab}>
                <TabPane tabId={'1'}>
                    <Row>
                        <Col sm="12">
                            <h4>Tab 1 Contents</h4>
                        </Col>
                    </Row>
                </TabPane>
                <TabPane tabId={'2'}>
                    <Row>
                        <Col sm="6">
                            <Card body className="mt-2 ml-2">
                                <CardTitle>양자전략위원회</CardTitle>
                                <CardText>
                                국무총리를 위원장으로 하는 범부처 양자 기술 컨트롤타워로, 기존 양자기술특별위원회를 확대 개편한 '양자전략위원회'가 24일 신설됐다
                                </CardText>
                                <Button>자세히</Button>
                            </Card>
                        </Col>
                        <Col sm="6">
                        <Card body className="mt-2 mr-2">
                                <CardTitle>양자전략위원회</CardTitle>
                                <CardText>
                                국무총리를 위원장으로 하는 범부처 양자 기술 컨트롤타워로, 기존 양자기술특별위원회를 확대 개편한 '양자전략위원회'가 24일 신설됐다
                                </CardText>
                                <Button>자세히</Button>
                            </Card>
                        </Col>
                    </Row>
                </TabPane>
            </TabContent>
        </div>
    )
}

export default  TabsStrap;