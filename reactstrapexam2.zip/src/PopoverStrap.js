import { useEffect, useState } from "react";
import {Button, Popover, PopoverHeader,PopoverBody, Progress} from 'reactstrap';
function PopoverStrap() {
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState(0);
    useEffect(()=>{
        plusValue();
    },[])

    let tvalue = value;
    const plusValue = () => {
        let timerId = setInterval(()=>{
            tvalue += 1;
            setValue(tvalue);
        },100);
        setTimeout(()=> {
            clearInterval(timerId);
        }, 10000)
    }
    
    return(
        <div style={{width:"800px"}}>
            <Button onClick={()=>setOpen(!open)} id="Popvoer1">양자전략위원회</Button>
            <Popover placement="bottom" isOpen={open} target="Popvoer1" toggle={()=>setOpen(!open)}>
                <PopoverHeader>정부 양자기술 컨트롤타워</PopoverHeader>
                <PopoverBody>
                국무총리를 위원장으로 하는 범부처 양자 기술 컨트롤타워로, 기존 양자기술특별위원회를 확대 개편한 '양자전략위원회'가 24일 신설됐다.
                </PopoverBody>
            </Popover><br/><br/>
            <Progress value={value}/>
        </div>
    )
}

export default PopoverStrap;