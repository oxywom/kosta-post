import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import InputGroupStrap from './InputGroupStrap';
import ListGroupStrap from './ListGroupStrap';
import ModalStrap from './ModalStrap';
import ModalStrap2 from './ModalStrap2';
import ModalStrap3 from './ModalStrap3';
import NavbarStrap1 from './NavbarStrap1';
import PaginationStrap from './PaginationStrap';
import PopoverStrap from './PopoverStrap';
import TableStrap from './TableStrap';
import TabsStrap from './TabsStrap';
import TooltipsStrap from './TooltipStrap';
import Sweetalert2Basic from './Sweetalert2Basic';
import SweetalertPosition from './SweetalertPosition';
import SweetalertConfirm from './SweetalertConfirm';
function App() {
  return (
    <div>
      {/* <InputGroupStrap/> */}
      {/* <ListGroupStrap/> */}
      {/* <ModalStrap/> */}
      {/* <ModalStrap2/> */}
      {/* <ModalStrap3/> */}
      {/* <NavbarStrap1/> */}
      {/* <PaginationStrap/> */}
      <PopoverStrap/>
      {/* <TableStrap/> */}
      {/* <TabsStrap/> */}
      {/* <TooltipsStrap/> */}
      {/* <Sweetalert2Basic/> */}
      {/* <SweetalertPosition/> */}
      {/* <SweetalertConfirm/> */}
    </div>
  );
}

export default App;
