import { useState } from "react";
import { ListGroup, ListGroupItem, Badge, ListGroupItemHeading, ListGroupItemText } from "reactstrap";
function ListGroupStrap() {
    return(
        <div style={{width:"800px"}}>
            <ListGroup>
                <ListGroupItem className="justify-content-between">Cras justo odio<Badge pill>14</Badge></ListGroupItem>
                <ListGroupItem className="justify-content-between">Dapibus ac facilisis in <Badge pill>2</Badge></ListGroupItem>
                <ListGroupItem className="justify-content-between">Morbi leo risus <Badge pill>1</Badge></ListGroupItem>
            </ListGroup> <br/><br/>
            <ListGroup>
                <ListGroupItem className="justify-content-between" color="success" tag="a" href="https://n.news.naver.com/mnews/article/018/0005603396?sid=102">전국 최초 초광역 도심항공교통, 충청권서 첫 걸음</ListGroupItem>
                <ListGroupItem className="justify-content-between" tag="a" href="https://n.news.naver.com/mnews/article/081/0003403405?sid=102">“온몸 찢기는 느낌” “뱃속 괴물”…마약 투약 유명인들의 후회</ListGroupItem>
                <ListGroupItem className="justify-content-between" tag="a" href="https://n.news.naver.com/mnews/article/421/0007134785?sid=102">김의철 전 KBS 사장, '해임정지' 신청 기각에 불복해 항고</ListGroupItem>
            </ListGroup><br/><br/>
            <ListGroup>
                <ListGroupItem>
                    <ListGroupItemHeading>두바이서 7억상당 마약 밀수한 韓 고교생…1심 판결에 檢 불복 항소</ListGroupItemHeading>
                    <ListGroupItemText>두바이에서 7억여원 상당 케타민을 국내로 밀수한 뒤, 적발되자 마피아 아들의 강요 …</ListGroupItemText>
                </ListGroupItem>
                <ListGroupItem>
                    <ListGroupItemHeading>[속보]횡성 ‘소 럼피스킨병’ 발생</ListGroupItemHeading>
                    <ListGroupItemText>속보=횡성에서 소 바이러스성 전염병인 ‘럼피스킨병’이 발생했다. 농림축산검역본부는 …</ListGroupItemText>
                </ListGroupItem>
                <ListGroupItem>
                    <ListGroupItemHeading>2억뷰 '공중부양 춤' 세계 1위 대구 중3 남학생 '화제'</ListGroupItemHeading>
                    <ListGroupItemText>박예진 인턴 기자 = 빠른 발놀림에 마치 공중에서 걷는 듯한 ‘슬릭백’ 춤 영상으 …</ListGroupItemText>
                </ListGroupItem>
            </ListGroup>

        </div>
    )
}
export default ListGroupStrap;